﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class viewreport : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

        //if (!this.IsPostBack)
        //{
        //    string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        //    using (SqlConnection conn = new SqlConnection(constr))
        //    {
        //        using (SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblFiles", conn))
        //        {
        //            DataTable dt = new DataTable();
        //            sda.Fill(dt);
        //            GridView2.DataSource = dt;
        //            GridView2.DataBind();
                    
        //        }
        //    }
        //}
    }
    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView dr = (DataRowView)e.Row.DataItem;
            string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["Data"]);
            (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       // string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
       string con = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
      // string con = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
       SqlConnection sqlconn = new SqlConnection(con);
       sqlconn.Open();
       SqlCommand sqlcom = new SqlCommand();
       string sqlquery = "Select * from tblFiles where [id] like'" + txtpn.Text + "%'";
       sqlcom.CommandText = sqlquery;
       sqlcom.Connection = sqlconn;
       sqlcom.Parameters.AddWithValue("id", txtpn.Text);
       string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
       using (SqlConnection conn = new SqlConnection(constr))
       {
           using (SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblFiles", conn))
           {
               DataTable dt = new DataTable();
               sda.Fill(dt);
               GridView1.DataSource = dt;
               GridView1.DataBind();
           }
       }
    }
}
