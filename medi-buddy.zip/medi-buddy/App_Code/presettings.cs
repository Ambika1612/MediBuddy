﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
//using GsmComm.GsmCommunication;
//using GsmComm.PduConverter;
using System.Net.Mail;
using System.Net;
using System.IO;
namespace presettings
{
        
    public class Class1
    {
        public static string conStr = "Data Source=./sqlexpress;Initial Catalog=onlinemovie;Integrated Security=True";



        public static string getRandomNumber(int from, int to)
        {
            Random r = new Random();
            return r.Next(from, to).ToString();

        }
        public static Boolean sendEmail(string subject, string message, string toaddress)
        {



            try
            {

                string toemail;


                MailAddress mailfrom = new MailAddress("projecttravel2@gmail.com");

                MailMessage newmsg = new MailMessage("projecttravel2@gmail.com", toaddress);

                newmsg.Subject = subject;
                newmsg.Body = message;//"Dear Applicant \n \n your paper has been: ";// +cboApprove.Text.ToString() + " \n \n From \n \n CMS " + cboApprove.Text.ToString();



                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.UseDefaultCredentials = false;


                smtp.Credentials = new NetworkCredential("projecttravel2@gmail.com", "Bjp12345");

                smtp.EnableSsl = true;
                smtp.Send(newmsg);

                return true;
            }
            catch (Exception ex)
            {
                return false; // lblError.Text = ex.Message.ToString();
            }
        }

        public static string SendSMS(string mobile, string message)
        {
            //string url = "http://sms.foosms.com/pushsms.php?username=kulkarnigururaj&password=gururajmca1&sender=Hescom&to=" + mobile + "&message=" + message;
            // string url = "http://site6.way2sms.com/jsp/Main.jsp?id=9035774216.300007&sender=somanath=" + mobile + "&message=" + message;


            //  string url = "http://sms.foosms.com/pushsms.php?username=projectmaker&api_password=6c834pfwlac7m9339&sender=EBFLAG&to=" + mobile + "&message=" + message + "&priority=8";
            string url = "http://www.kutility.in/app/smsapi/index.php?key=35B0CEDEB6F35D&routeid=416&type=text&contacts=" + mobile + "&senderid=PROLAB" + "&msg=" + message;// Hello+People%2C+have+a+great+day";

            HttpWebRequest httpreq = (HttpWebRequest)WebRequest.Create(url);
            try
            {
                //if (EnableSMS != null && !EnableSMS.Trim().Equals("") && EnableSMS.Trim().ToLower().Equals("true"))
                HttpWebResponse httpres = (HttpWebResponse)httpreq.GetResponse();
                StreamReader sr = new StreamReader(httpres.GetResponseStream());
                string results = sr.ReadToEnd();
                sr.Close();
                return results;
            }
            catch (Exception ex)
            {

                return ex.Message.ToString();
            }
        }
    }

}
