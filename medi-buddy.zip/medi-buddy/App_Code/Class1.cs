﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace meddy
{


    public class Class1
    {
        public SqlConnection con = new SqlConnection();
        public SqlCommand cmd = new SqlCommand();
        public DataSet ds = new DataSet();
        public SqlDataAdapter ada = new SqlDataAdapter();
        public SqlDataReader dr;
        public Class1()
        {
            //
            // TODO: Add constructor logic here
            //

            if (con.State == ConnectionState.Open)
            {
                con.Close();
                con.Dispose();
            }
            con.ConnectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True";
            con.Open();
            cmd.Connection = con;

        }
        public void exe(string qry)
        {
            con.Close();
            con.Open();
            cmd.CommandText = qry;
            dr = cmd.ExecuteReader();
        }
    }
}