﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class docdetail : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        try
        {
            String get = "insert into doc values(@fullname,@speciality,@ftime,@ttime,@phone,@email,@address)";


            SqlCommand cmd = new SqlCommand(get, con);


            //cmd.Parameters.Add("@userid", txtui.Text);
            cmd.Parameters.Add("@fullname", txtname.Text);
            cmd.Parameters.Add("@speciality", DropDownList1.Text);
           cmd.Parameters.Add("@ftime", txtft.Text);
           //cmd.Parameters.Add("@ftime", TimeSelector1.Minute.ToString());
           cmd.Parameters.Add("@ttime", txttt.Text);
            cmd.Parameters.Add("@phone", txtphno.Text);
            cmd.Parameters.Add("@email", txtemail.Text);
            cmd.Parameters.Add("@address", txtadd.Text);
            

            cmd.ExecuteNonQuery();



            Label1.Text = "YOU ARE REGISTERED IN THIS WEBSITE";
            Label1.Visible = true;

            Response.Redirect("docindex.aspx");
            
            con.Close();
        }

        catch (Exception ex)
        {

            Label1.Text = ex.Message.ToString();
            Label1.Visible = true;

            //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;


        }
    
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
