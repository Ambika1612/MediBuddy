﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using presettings;
using System.Net;
using System.Net.Mail;

public partial class sendmsg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        Retriveid();
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            txtpid.Text = GridView1.SelectedRow.Cells[1].Text;
            txtpn.Text = GridView1.SelectedRow.Cells[2].Text;
            txtspe.Text = GridView1.SelectedRow.Cells[3].Text;
            txtdn.Text = GridView1.SelectedRow.Cells[4].Text;
            txtdate.Text = GridView1.SelectedRow.Cells[5].Text;
            txtphno.Text = GridView1.SelectedRow.Cells[6].Text;
            txtemail.Text = GridView1.SelectedRow.Cells[7].Text;
        }

    }

    private void Retriveid()
    {
        try
        {
            string query = "Select IDENT_CURRENT('conapp')";
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int value = int.Parse(reader[0].ToString()) + 1;
                txtaid.Text = value.ToString();

            }

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        try
        {
            
            String get = "insert into conapp values(@Patient_ID,@Patient_Name,@Specialization,@Doctor,@Date,@Phone_nor,@Email)";


            SqlCommand cmd = new SqlCommand(get, con);


            cmd.Parameters.AddWithValue("@Patient_ID", txtpid.Text);
            cmd.Parameters.AddWithValue("@Patient_Name", txtpn.Text);
            cmd.Parameters.AddWithValue("@Specialization", txtspe.Text);
            cmd.Parameters.AddWithValue("@Doctor", txtdn.Text);
            cmd.Parameters.AddWithValue("@Date", txtdate.Text);
            cmd.Parameters.AddWithValue("@Phone_nor", txtphno.Text);
            cmd.Parameters.AddWithValue("@Email", txtemail.Text);

            cmd.ExecuteNonQuery();


            con.Close();
            con.Open();


            string get1 = "Select * from conapp";
            SqlCommand cmd1 = new SqlCommand(get1, con);
            SqlDataReader dr2 = cmd1.ExecuteReader();
            dr2.Read();
            // string x = dr2.GetValue(0).ToString();
            string y = txtphno.Text.ToString();

            String msg = "Your Appointmennt has been confirmed with Appoitment ID:  " + txtaid.Text + ",   On  "+ txtdate.Text+"  " ;

            presettings.Class1.SendSMS(y, msg);
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Appoiment Confirmed.');", true);

            txtspe.Text = "";
            txtpn.Text = "";
            txtpid.Text = "";
            txtphno.Text = "";
            txtemail.Text = "";
            txtdn.Text = "";
            txtaid.Text = "";
            


            // Label8.Text = "YOU ARE REGISTERED IN THIS WEBSITE";
            //Label8.Visible = false;
            //  ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Appointment Confirm.')");
            // Response.Redirect("pindex.aspx");

            // con.Close();


            //using (MailMessage mm = new MailMessage("projectmaker.dontreply@gmail.com", txtemail.Text))
            //{
            //    //mm.Subject = txtaid.Text;
            //    //mm.Body = txtBody.Text;

            //    mm.Subject = "Your Appointmennt has been confirmed with Appoitment ID:  " + txtaid.Text + "  ";

            //    mm.IsBodyHtml = false;
            //    SmtpClient smtp = new SmtpClient();
            //    smtp.Host = "smtp.gmail.com";
            //    smtp.EnableSsl = true;
            //    NetworkCredential NetworkCred = new NetworkCredential("projectmaker.dontreply@gmail.com", "ProMake@143");
            //    smtp.UseDefaultCredentials = true;
            //    smtp.Credentials = NetworkCred;
            //    smtp.Port = 587;
            //    smtp.Send(mm);
            //    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Appoiment Confirmed.');", true);

            //}
        }


        catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
            lblResult.Visible = true;
        }
       
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString);

        ////connection = new SqlConnection(conn);
        //string local_mobile, id;
        //con.Open();
        //string get = "Select Appid,Patientid,Patientname,phone from conapp";
        //SqlCommand cmd1 = new SqlCommand(get, con);
        //SqlDataReader dr2 = cmd1.ExecuteReader();
        //dr2.Read();
        //id = dr2.GetValue(0).ToString();
        //local_mobile = dr2.GetValue(3).ToString();

        //String msg = "Your ID is" + id + "Successfully Added :";

        //presettings.Class1.SendSMS(local_mobile, msg);
        ////SMSSender.SendSMS(local_mobile, msg);
        //con.Close();

      
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        try
        {
        String get = "delete * appiontment where Patientid='"+ txtpid.Text+"' and specialization='" + txtspe.Text + "' and doctor='" + txtdn.Text+"'";
             SqlCommand cmd = new SqlCommand(get, con);
            cmd.ExecuteNonQuery();


            con.Close();
            con.Open();


            string get1 = "Select * from conapp";
            SqlCommand cmd1 = new SqlCommand(get1, con);
            SqlDataReader dr2 = cmd1.ExecuteReader();
            dr2.Read();
            // string x = dr2.GetValue(0).ToString();
            string y = txtphno.Text.ToString();

            String msg = "Your Appointment has been Canceled Please Request Again " ;

            presettings.Class1.SendSMS(y, msg);

            
              using (MailMessage mm = new MailMessage("projectmaker.dontreply@gmail.com", txtemail.Text))
        {
            //mm.Subject = txtaid.Text;
            //mm.Body = txtBody.Text;

            mm.Subject = "Your Appointmennt has been Canceled Please Request Again ";
           
            mm.IsBodyHtml = false;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential("projectmaker.dontreply@gmail.com", "ProMake@143");
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Appoointment Canceled Please Request Again.');", true);

        }
        }

             catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
            lblResult.Visible = true;
        }
        
    }
    }

