﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;

public partial class feedback : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        con.Open();
        try
        {
            String get = "insert into fb values(@Feedback,@Opinion)";


            SqlCommand cmd = new SqlCommand(get, con);


            if (RadioButton1.Checked == true)
            {
                cmd.Parameters.Add("@Feedback", RadioButton1.Text);
            }
            else
            {
                cmd.Parameters.Add("@Feedback", RadioButton2.Text);
            }

            
            cmd.Parameters.Add("@Opinion", TextBox1.Text );
           


            cmd.ExecuteNonQuery();


            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Thank You For Feedback.');", true);

            con.Close();
        }

        catch (Exception ex)
        {

            Label1.Text = ex.Message.ToString();
            Label1.Visible = true;

            //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;


        }
    

    }
}
