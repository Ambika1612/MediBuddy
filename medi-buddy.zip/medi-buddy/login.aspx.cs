﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        txtun.Text = "";
        txtpass.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String get;
        con.Open();
        if (DropDownList1.SelectedItem.Text == "Admin")
        {

            //  get = "Select * from register where username='" + txtun.Text + "'" + "   and  password ='" + txtpass.Text + "'";
            //  SqlCommand cmd = new SqlCommand(get, con);

            // SqlDataReader dr = cmd.ExecuteReader();

            //dr.Read();

            //string user, pass;
            //user = txtun.Text;
            //pass = txtpass.Text;
            //if (txtun.Text == "aaa" && txtpass.Text == "aaa")
            //{
                //  string message = "LOGIN SUCCESSFUL";
                // MessageBox.show(message);
                Response.Redirect("aindex.aspx");
            //}

            //else
            //{
            //    Response.Redirect("home.aspx");
            //}



        }
        else if (DropDownList1.SelectedItem.Text == "Doctor")
        {
            get = "Select * from register where username='" + txtun.Text + "'" + "   and  password ='" + txtpass.Text + "'";
            SqlCommand cmd = new SqlCommand(get, con);

            SqlDataReader dr = cmd.ExecuteReader();

            dr.Read();
            if (dr.HasRows)
            {
              //  string message = "LOGIN SUCCESSFUL";
               // MessageBox.show(message);
                Response.Redirect("docindex.aspx");
            }

            else
            {
                Response.Redirect("home.aspx");
            }


        }
        
       

        else
        {

            get = "Select * from register where username='" + txtun.Text + "'" + "   and  password ='" + txtpass.Text + "' ";
            SqlCommand cmd = new SqlCommand(get, con);
            SqlDataReader dr = cmd.ExecuteReader();


            dr.Read();
            if (dr.HasRows)
            {
                // Session["bankcode"] = dr.GetValue(0).ToString();
                Response.Redirect("pindex.aspx");


            }
            else
            {
                Label1.Text = "TRY ONCE AGAIN NOT A VALID USER";
                Label1.Visible = false;

            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("reg.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("forgot.aspx");
    }
}

