﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class viewdoc : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (GridView1.SelectedRow != null)
        {
            
            Server.Transfer("~/appoint.aspx");
           // Page.ClientScript.RegisterStartupScript(this.GetType(), "scripts", "<script>alert('make an appointment.');</script>");
        }

        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please select a row.')");
        }

    //  txtname.Text = GridView1.SelectedRow.Cells[0].Text;
    //    txtspec.Text = GridView1.SelectedRow.Cells[1].Text;
       // Response.Redirect("appoint.aspx");
    }
}



