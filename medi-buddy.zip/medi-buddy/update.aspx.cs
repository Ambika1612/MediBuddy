﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class update : System.Web.UI.Page
{
    SqlConnection con1 = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            //txtname.Text = GridView1.SelectedRow.Cells[0].Text;
            txtname.Text = GridView1.SelectedRow.Cells[1].Text;
            DropDownList1.Text = GridView1.SelectedRow.Cells[2].Text;
            txtft.Text = GridView1.SelectedRow.Cells[3].Text;
            txttt.Text = GridView1.SelectedRow.Cells[4].Text;
            txtphno.Text = GridView1.SelectedRow.Cells[5].Text;
            txtemail.Text = GridView1.SelectedRow.Cells[6].Text;
            txtadd.Text = GridView1.SelectedRow.Cells[7].Text;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con1.Open();
        String get2 = "select * from doc where fullname='" + txtname.Text + "'";
            SqlCommand cmd2 = new SqlCommand(get2, con1);
            cmd2.ExecuteNonQuery();
            cmd2 = new SqlCommand(get2, con1);
            SqlDataReader dr1 = cmd2.ExecuteReader();
            dr1.Read();
            if (dr1.HasRows)
            {
                //int localbal = Convert.ToInt32(dr1["Amount"].ToString());
                dr1.Close();
                string up = "update doc set ftime=" + txtft.Text + " and ttime=" + txttt.Text + " and phone=" + txtphno.Text + " and email=" + txtemail.Text + " and address=" + txtadd.Text + " where  fullname='" + txtname.Text + "'";
                cmd2 = new SqlCommand(up, con1);
                cmd2.ExecuteNonQuery();
            }
                
            else
            {
                dr1.Close();
                con1.Close();
                Label1.Text = "Failed to update profile";
                Label1.Visible = true;

            } 
            }
    protected void  TextBox1_TextChanged(object sender, EventArgs e)
{

}
}

