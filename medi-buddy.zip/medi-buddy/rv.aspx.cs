﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class rv : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!this.IsPostBack)
        //{
        //    string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        //    using (SqlConnection conn = new SqlConnection(constr))
        //    {
        //        using (SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblFiles", conn))
        //        {
        //            DataTable dt = new DataTable();
        //            sda.Fill(dt);
        //            gvImages.DataSource = dt;
        //            gvImages.DataBind();
        //        }
        //    }
        //}
    }

    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView dr = (DataRowView)e.Row.DataItem;
            string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["Data"]);
           // (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
        }
    }

    protected void Upload(object sender, EventArgs e)
    {
        //byte[] bytes;
        //using (BinaryReader br = new BinaryReader(FileUpload1.PostedFile.InputStream))
        //{
        //    bytes = br.ReadBytes(FileUpload1.PostedFile.ContentLength);
        //}
        string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        //using (SqlConnection conn = new SqlConnection(constr))
        //{
        //    string sql = "INSERT INTO tblFiles VALUES(@Name, @ContentType, @Data)";
        //    using (SqlCommand cmd = new SqlCommand(sql, conn))
        //    {
        //        cmd.Parameters.AddWithValue("@Name", Path.GetFileName(FileUpload1.PostedFile.FileName));
        //        cmd.Parameters.AddWithValue("@ContentType", FileUpload1.PostedFile.ContentType);
        //        cmd.Parameters.AddWithValue("@Data", bytes);
        //        conn.Open();
        //        cmd.ExecuteNonQuery();
        //        conn.Close();
        //    }
        //}

        Response.Redirect(Request.Url.AbsoluteUri);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string con = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        SqlConnection sqlconn = new SqlConnection(con);
        sqlconn.Open();
        SqlCommand sqlcom = new SqlCommand();
        string sqlquery = "Select * from multireport where [Specialization] like'" + TextBox2.Text + "%' and [Doctor] like'" + TextBox1.Text + "%'";
        sqlcom.CommandText = sqlquery;
        sqlcom.Connection = sqlconn;
        sqlcom.Parameters.AddWithValue("Specialization", TextBox2.Text);
        sqlcom.Parameters.AddWithValue("Doctor", TextBox1.Text);
        string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(constr))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM multireport", conn))
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gvImages.DataSource = dt;
                gvImages.DataBind();
            }
        }
    }
    protected void gvImages_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}