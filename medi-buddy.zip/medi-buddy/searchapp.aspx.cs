﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data.Sql;
//using System.Configuration;

public partial class searchapp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string con = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        SqlConnection sqlconn = new SqlConnection(con);
        sqlconn.Open();
        SqlCommand sqlcom = new SqlCommand();
        string sqlquery = "Select * from appiontment where [doctor] like'" + txtname.Text + "%' ";
        sqlcom.CommandText = sqlquery;
        sqlcom.Connection = sqlconn;
        sqlcom.Parameters.AddWithValue("doctor", txtname.Text);
        DataTable dt = new DataTable();
        SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
        sda.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (GridView1.SelectedRow != null)
        {

            Server.Transfer("~/sendmsg.aspx");
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "scripts", "<script>alert('make an appointment.');</script>");
        }

        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please select a row.')");
        }

    }
}
