﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Collections;
using System.Configuration;

public partial class multireport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        FileUpload1.Attributes["multiple"] = "multiple";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            for (int i = 0; i < Request.Files.Count; i++)
            {
                HttpPostedFile postedFile = Request.Files[i];
                if (postedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(postedFile.FileName);
                    string contentType = postedFile.ContentType;
                    using (Stream fs = postedFile.InputStream)
                    {
                        using (BinaryReader br = new BinaryReader(fs))
                        {
                            byte[] bytes = br.ReadBytes((Int32)fs.Length);
                            string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
                            using (SqlConnection con = new SqlConnection(constr))
                            {
                                string query = "insert into multireport values (@Patient_Name,@Specialization,@Doctor,@Phone,@Email,@Prescription,@File_Name,@Content,@Data)";
                                using (SqlCommand cmd = new SqlCommand(query))
                                {
                                    cmd.Connection = con;
                                    cmd.Parameters.AddWithValue("@Patient_Name", txtpn.Text);
                                    cmd.Parameters.AddWithValue("@Specialization", txtspe.Text);
                                    cmd.Parameters.AddWithValue("@Doctor", txtdn.Text);
                                    cmd.Parameters.AddWithValue("@Phone", txtphno.Text);
                                    cmd.Parameters.AddWithValue("@Email", txtemail.Text);
                                    cmd.Parameters.AddWithValue("@Prescription", txtpre.Text);
                                    cmd.Parameters.AddWithValue("@File_Name", filename);
                                    cmd.Parameters.AddWithValue("@Content", contentType);
                                    cmd.Parameters.AddWithValue("@Data", bytes);
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Report is Submited.');", true);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
        }

    }
}
