﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class createaccount : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    string Account_nor = "SBI";
    string A_N = "AXIS";
    protected void Page_Load(object sender, EventArgs e)
    {

       
    }
    public void GenerateAutoID1()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("Select Count(Account_nor) from account  ", con);
        int i = Convert.ToInt32(cmd.ExecuteScalar());
        con.Close();
        i++;
        txtan.Text = A_N + "0" + i.ToString();
    }

    public void GenerateAutoID()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("Select Count(Account_nor) from saccount",con);
        int i = Convert.ToInt32(cmd.ExecuteScalar());
        con.Close();
        i++;
        txtan.Text = Account_nor + "0" + i.ToString();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        try
        {
           // if (DropDownList1.Text = "SBI")
           // {
                String get = "insert into account values(@Bank_Name,@Account_nor,@Name,@Phone_number,@Email)";


                SqlCommand cmd = new SqlCommand(get, con);



                cmd.Parameters.Add("@Bank_Name", DropDownList1.Text);
                cmd.Parameters.Add("@Account_nor", txtan.Text);
                cmd.Parameters.Add("@Name", txtfn.Text);
                cmd.Parameters.Add("@Phone_number", txtpn.Text);
                cmd.Parameters.Add("@Email", txtemail.Text);


                cmd.ExecuteNonQuery();



                Label1.Text = "YOUR ACCOUNT HAS BEEN CREATED";
                Label1.Visible = true;
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('YOUR ACCOUNT HAS BEEN CREATED.');", true);
                //Response.Redirect("home.aspx");
                con.Close();
                GenerateAutoID();

            }
          /**  else
            {
                String get = "insert into account values(@Bank_Name,@Account_nor,@Name,@Phone_number,@Email)";


                SqlCommand cmd = new SqlCommand(get, con);



                cmd.Parameters.Add("@Bank_Name", DropDownList1.Text);
                cmd.Parameters.Add("@Account_nor", txtan.Text);
                cmd.Parameters.Add("@Name", txtfn.Text);
                cmd.Parameters.Add("@Phone_number", txtpn.Text);
                cmd.Parameters.Add("@Email", txtemail.Text);


                cmd.ExecuteNonQuery();



                Label1.Text = "YOUR ACCOUNT HAS BEEN CREATED";
                Label1.Visible = false;
                Response.Redirect("home.aspx");
                con.Close();
                GenerateAutoID();
            }  
        } **/

        catch (Exception ex)
        {

            Label2.Text = ex.Message.ToString();
            Label2.Visible = false;

            //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;


        }
    


    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            if (DropDownList1.Text == "SBI")
            {
                GenerateAutoID();
            }
            else
            {
                GenerateAutoID1();
            }
        }
        

           }
}
