﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class reg : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
   
    protected void Page_Load(object sender, EventArgs e)
    {
        Retriveid();
    }

    private void Retriveid()
    {
        try
        {
            string query = "Select IDENT_CURRENT('register')";
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int value = int.Parse(reader[0].ToString()) + 1;
                txtid.Text = value.ToString();

            }

        }
        catch (Exception ex)
        {
            Label2.Text = ex.Message.ToString();
            Label2.Visible = true;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        
        con.Open();
        try
        {
            //String get = "insert into register values(@usertype,@firstname,@lastname,@phoneno,@address,@email,@username,@password,@confirmpassword)";
            String get = "insert into register values('" + DropDownList1.Text + "' ,'" + txtfn.Text + "','" + txtln.Text + "','" + txtpn.Text + "','" + txtadd.Text + "','" + txtemail.Text + "','" + txtun.Text + "','" + txtpass.Text + "','" + txtcp.Text + "')";

            
            SqlCommand cmd = new SqlCommand(get, con);


            //cmd.Parameters.AddWithValue("@usertype", DropDownList1.Text);
            //cmd.Parameters.AddWithValue("@firstname", txtfn.Text);
            //cmd.Parameters.AddWithValue("@lastname", txtln.Text);
            //cmd.Parameters.AddWithValue("@phoneno", txtpn.Text);
            //cmd.Parameters.AddWithValue("@address", txtadd.Text);
            //cmd.Parameters.AddWithValue("@email", txtemail.Text);
            //cmd.Parameters.AddWithValue("@username", txtun.Text);
            //cmd.Parameters.AddWithValue("@password", txtpass.Text);
            //cmd.Parameters.AddWithValue("@confirmpassword", txtcp.Text);

            cmd.ExecuteNonQuery();

             DropDownList1.Text= "";
            txtfn.Text = "";
             txtln.Text= "";
             txtpn.Text= "";
            txtadd.Text= "";
             txtemail.Text= "";
             txtun.Text= "";
           txtpass.Text= "";
             txtcp.Text= "";

            Label1.Text = "YOU ARE REGISTERED IN THIS WEBSITE";
            Label1.Visible = true;
            if (DropDownList1.SelectedItem.Text == "Doctor")
            {
                Response.Redirect("docdetail.aspx");
            }
            else
            {

                Response.Redirect("login.aspx");
            }
            con.Close();
            
        }

        catch (Exception ex)
        {

            Label2.Text = ex.Message.ToString();
            Label2.Visible = true;
                
                //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;


        }
    


    }
}
