﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data.Sql;

public partial class forgot : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string con = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
        SqlConnection sqlconn = new SqlConnection(con);
        sqlconn.Open();
        SqlCommand sqlcom = new SqlCommand();
        string sqlquery = "Select id,usertype,username,password from register where [phoneno] like'" + txtpn.Text + "%'";
        sqlcom.CommandText = sqlquery;
        sqlcom.Connection = sqlconn;
        sqlcom.Parameters.AddWithValue("phoneno", txtpn.Text);
        DataTable dt = new DataTable();
        SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
        sda.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
}
