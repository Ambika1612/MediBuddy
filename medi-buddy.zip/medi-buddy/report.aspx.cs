﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            txtpn.Text = GridView1.SelectedRow.Cells[2].Text;
          //  txtspec.Text = GridView1.SelectedRow.Cells[1].Text;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection connection = null;
        try
        {
            FileUpload img = (FileUpload)FileUpload1;
            Byte[] imgByte = null;
            if (img.HasFile && img.PostedFile != null)
            {
                //To create a PostedFile
                HttpPostedFile File = FileUpload1.PostedFile;
                //Create byte Array with file len
                imgByte = new Byte[File.ContentLength];
                //force the control to load data in array
                File.InputStream.Read(imgByte, 0, File.ContentLength);
                FileUpload1.FileName.ToString();
                FileUpload1.SaveAs(Server.MapPath("~\\Upload\\" + FileUpload1.FileName.ToString()));
               // FileUpload1.SaveAs(Server.MapPath("~\\Upload\\" + FileUpload1.FileName.ToString()));
            }
            // Insert the employee name and image into db
            // string conn = ConfigurationManager.ConnectionStrings["DatabaseConnectionString1"].ConnectionString;
            string conn = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
            //  SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DatabaseConnectionString1"].ConnectionString);

            connection = new SqlConnection(conn);

            connection.Open();
            string sql = "INSERT INTO report(patientname,prescription,report) VALUES(@patientname,@prescription,@report) SELECT @@IDENTITY";
            SqlCommand cmd = new SqlCommand(sql, connection);
            cmd.Parameters.AddWithValue("@patientname", txtpn.Text.Trim());
             cmd.Parameters.AddWithValue("@prescription", txtpre.Text.Trim());
            cmd.Parameters.AddWithValue("@report", imgByte);
            int reportid = Convert.ToInt32(cmd.ExecuteScalar());
            lblResult.Text = String.Format("Report ID is {0}", reportid);
        }
        catch
        {
            lblResult.Text = "There was an error";
        }
        finally
        {
            connection.Close();
        }
    


    }
}
