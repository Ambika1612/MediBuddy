﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using presettings;
using System.Net;
using System.Net.Mail;

public partial class docreport : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        Retriveid();
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            txtpn.Text = GridView1.SelectedRow.Cells[1].Text;
            DropDownList1.Text = GridView1.SelectedRow.Cells[2].Text;
            txtdn.Text = GridView1.SelectedRow.Cells[3].Text;
            txtphno.Text = GridView1.SelectedRow.Cells[4].Text;
            txtemail.Text = GridView1.SelectedRow.Cells[5].Text;
        }

        FileUpload1.Attributes["multiple"] = "multiple";
    }

    private void Retriveid()
    {
        try
        {
            string query = "Select IDENT_CURRENT('multireport')";
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int value = int.Parse(reader[0].ToString()) + 1;
                txtid.Text = value.ToString();

            }

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            for (int i = 0; i < Request.Files.Count; i++)
            {
                HttpPostedFile postedFile = Request.Files[i];
                if (postedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(postedFile.FileName);
                    string contentType = postedFile.ContentType;
                    using (Stream fs = postedFile.InputStream)
                    {
                        using (BinaryReader br = new BinaryReader(fs))
                        {
                            byte[] bytes = br.ReadBytes((Int32)fs.Length);
                            string constr = ConfigurationManager.ConnectionStrings["MEDConnectionString"].ConnectionString;
                            using (SqlConnection con = new SqlConnection(constr))
                            {
                                string query = "insert into multireport values (@Patient_Name,@Specialization,@Doctor,@Phone,@Email,@Prescription,@File_Name,@Content,@Data)";
                                using (SqlCommand cmd = new SqlCommand(query))
                                {
                                    cmd.Connection = con;
                                   // cmd.Parameters.AddWithValue("@Report_ID", txtid.Text);
                                    cmd.Parameters.AddWithValue("@Patient_Name", txtpn.Text);
                                    cmd.Parameters.AddWithValue("@Specialization", DropDownList1.Text);
                                    cmd.Parameters.AddWithValue("@Doctor", txtdn.Text);
                                    cmd.Parameters.AddWithValue("@Phone",txtphno.Text);
                                    cmd.Parameters.AddWithValue("@Email", txtemail.Text);
                                    cmd.Parameters.AddWithValue("@Prescription", txtpre.Text);
                                    cmd.Parameters.AddWithValue("@File_Name", filename);
                                    cmd.Parameters.AddWithValue("@Content", contentType);
                                    cmd.Parameters.AddWithValue("@Data", bytes);
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                    con.Open();


                                    string get1 = "Select * from multireport";
                                    SqlCommand cmd1 = new SqlCommand(get1, con);
                                    SqlDataReader dr2 = cmd1.ExecuteReader();
                                    dr2.Read();
                                    // string x = dr2.GetValue(0).ToString();
                                    string y = txtphno.Text.ToString();

                                    String msg = "Please Check for your report at ReportID :  " + txtid.Text + "  ";

                                    presettings.Class1.SendSMS(y, msg);


                                    using (MailMessage mm = new MailMessage("projectmaker.dontreply@gmail.com", txtemail.Text))
                                    {
                                        //mm.Subject = txtaid.Text;
                                        //mm.Body = txtBody.Text;

                                        mm.Subject = "Please Check for your report at ReportID:  " + txtid.Text + "  ";

                                        mm.IsBodyHtml = false;
                                        SmtpClient smtp = new SmtpClient();
                                        smtp.Host = "smtp.gmail.com";
                                        smtp.EnableSsl = true;
                                        NetworkCredential NetworkCred = new NetworkCredential("projectmaker.dontreply@gmail.com", "ProMake@143");
                                        smtp.UseDefaultCredentials = true;
                                        smtp.Credentials = NetworkCred;
                                        smtp.Port = 587;
                                        smtp.Send(mm);
                                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Report sent.');", true);

                                    }


                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
        }



    }
}
