﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class deposit : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        con.Open();
        try
        {
            String get2 = "select * from deposit where Bank_Name='" + DropDownList1.Text + "' and Account_Number='" + txtan.Text + "' and Phone='" + txtpn.Text + "'";
            SqlCommand cmd2 = new SqlCommand(get2, con);
            cmd2.ExecuteNonQuery();
            cmd2 = new SqlCommand(get2, con);
            SqlDataReader dr = cmd2.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                int localbal = Convert.ToInt32(dr["Amount"].ToString());
                dr.Close();
                string up = "update deposit set Amount=Amount+" + Convert.ToInt32(txtamt.Text) + " where Bank_Name='" + DropDownList1.Text + "' and Account_Number='" + txtan.Text + "' and Phone='" + txtpn.Text + "'";
                cmd2 = new SqlCommand(up, con);
                cmd2.ExecuteNonQuery();
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Amount Has Been Deposited Successfully');", true);
            }
            else
            {
                dr.Close();
                String get = "insert into deposit values(@Bank_Name,@Account_Number,@Phone,@Amount)";


                SqlCommand cmd = new SqlCommand(get, con);


                cmd.Parameters.Add("@Bank_Name", DropDownList1.Text);
                cmd.Parameters.Add("@Phone", txtpn.Text);
                cmd.Parameters.Add("@Account_Number", txtan.Text);
                cmd.Parameters.Add("@Amount", txtamt.Text);

                cmd.ExecuteNonQuery();


                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Amount Has Been Deposited Successfully');", true);
                Label1.Text = "Amount Has Been Deposited Successfully";
                Label1.Visible = true;


                con.Close();
            }
        }

        catch (Exception ex)
        {

            Label2.Text = ex.Message.ToString();
            Label2.Visible = true;

            //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;


        }
    

    }
   
}
