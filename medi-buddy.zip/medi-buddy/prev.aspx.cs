﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;



public partial class prev : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string picfile;
        picfile = FileUpload1.FileName.ToString();
         FileUpload1.SaveAs(Server.MapPath("~\\Upload\\" + FileUpload1.FileName.ToString()));
        
        try
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
            con.Open();
          //  string query = "insert into pr(id,pname,report) values (@id,@pname,@report)";
            string query = "insert into retimg(pname,report) values(@pname,@report)";
            SqlCommand dbcomm = new SqlCommand();
           // dbcomm.Parameters.AddWithValue("@id", TextBox1.Text.ToString());
            dbcomm.Parameters.AddWithValue("@pname", TextBox2.Text.ToString());
            dbcomm.Parameters.AddWithValue("@report", picfile);
            dbcomm.CommandText = query;
            dbcomm.Connection = con;
            dbcomm.CommandType = CommandType.Text;
            dbcomm.ExecuteNonQuery();
            con.Close();
           Label2.Text = "Success";
            Label2.Visible = true;
       

        }
        catch (Exception ex)
        {

            Label2.Text = ex.Message.ToString();
            Label2.Visible = true;
        }
       
        

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}
