﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;

public partial class Transfer : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    SqlConnection con1 = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    SqlConnection con2 = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         con.Open();
        try
        {
            String get3 = "select * from deposit where Bank_Name='" + DropDownList2.Text + "' and Account_Number='" + txtaccno.Text + "'";
            SqlCommand cmd = new SqlCommand(get3, con);
            cmd.ExecuteNonQuery();
            cmd = new SqlCommand(get3, con);
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                int localbal = Convert.ToInt32(dr["Amount"].ToString());
                dr.Close();
                string up = "update deposit set Amount=Amount+" + Convert.ToInt32(txtamt.Text) + " where Bank_Name='" + DropDownList2.Text + "' and Account_Number='" + txtaccno.Text + "'";
                cmd = new SqlCommand(up, con);
                cmd.ExecuteNonQuery();
            }
            else
            {
                dr.Close();
                String get = "insert into deposit values(@Bank_Name,@Account_Number,@Amount)";


                SqlCommand cmd1 = new SqlCommand(get, con);


                cmd1.Parameters.Add("@Bank_Name", DropDownList2.Text);
                cmd1.Parameters.Add("@Account_Number", txtaccno.Text);
                cmd1.Parameters.Add("@Amount", txtamt.Text);

                cmd1.ExecuteNonQuery();



                Label1.Text = "Amount Has Been Deposited Successfully";
                Label1.Visible = true;


                con.Close();
            }

            con1.Open();
             String get2 = "select * from deposit where Bank_Name='" + DropDownList1.Text + "' and Account_Number='" + txtan.Text + "'";
            SqlCommand cmd2 = new SqlCommand(get2, con1);
            cmd2.ExecuteNonQuery();
            cmd2 = new SqlCommand(get2, con1);
            SqlDataReader dr1 = cmd2.ExecuteReader();
            dr1.Read();
            if (dr1.HasRows)
            {
                int localbal = Convert.ToInt32(dr1["Amount"].ToString());
                dr1.Close();
                string up = "update deposit set Amount=Amount-" + Convert.ToInt32(txtamt.Text) + " where Bank_Name='" + DropDownList1.Text + "' and Account_Number='" + txtan.Text + "'";
                cmd2 = new SqlCommand(up, con1);
                cmd2.ExecuteNonQuery();
            }
                
            else
            {
                dr1.Close();
                con1.Close();
                Label2.Text = "YOUR ACCOUNT BALANCE IS LOW";
                Label2.Visible = true;

            } 
            }
        

 catch (Exception ex)
        {

            Label2.Text = ex.Message.ToString();
            Label2.Visible = true;

            //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;


        }
    }
      
    }
