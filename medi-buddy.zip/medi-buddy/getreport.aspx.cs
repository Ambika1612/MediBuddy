﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class getreport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            txtid.Text = GridView1.SelectedRow.Cells[0].Text;
            //DropDownList1.Text = GridView1.SelectedRow.Cells[2].Text;
            //txtdn.Text = GridView1.SelectedRow.Cells[3].Text;
            //txtphno.Text = GridView1.SelectedRow.Cells[4].Text;
            //txtemail.Text = GridView1.SelectedRow.Cells[5].Text;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Image1.ImageUrl = "ImageHandler.ashx?id=" + txtid.Text;
    }
}
