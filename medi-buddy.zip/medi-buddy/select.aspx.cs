﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class select : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            Response.Write("Name:" + selectedRow.Cells[0].Text+"</br>");
            Response.Write("specialization:" + selectedRow.Cells[1].Text + "</br>");
            txtname.Text = GridView1.SelectedRow.Cells[0].Text;
            txtspec.Text = GridView1.SelectedRow.Cells[1].Text;
        }
    }
    protected void txtspec_TextChanged(object sender, EventArgs e)
    {

    }
}
