﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;


public partial class appoint : System.Web.UI.Page
{
     SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MED;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.Page.PreviousPage != null)
        {
            GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("GridView1");
            GridViewRow selectedRow = GridView1.SelectedRow;
            txtname.Text = GridView1.SelectedRow.Cells[0].Text;
            txtspec.Text = GridView1.SelectedRow.Cells[1].Text;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        try
        {
            String get = "insert into appiontment values(@Patientid,@Patientname,@specialization,@doctor,@date,@phone,@email,@message)";


            SqlCommand cmd = new SqlCommand(get, con);

           // cmd.Parameters.AddWithValue("@Appointmentid", txtaid.Text);
            cmd.Parameters.AddWithValue("@Patientid", txtid.Text);
            cmd.Parameters.AddWithValue("@Patientname", txtpn.Text);
            cmd.Parameters.AddWithValue("@specialization", txtspec.Text);
            cmd.Parameters.AddWithValue("@doctor", txtname.Text);
            cmd.Parameters.AddWithValue("@date", txtdate.Text);
           // cmd.Parameters.AddWithValue("@time", TimeSelector1.AmPm.ToString());
            cmd.Parameters.AddWithValue("@phone", txtphno.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@message", txtmsg.Text);

            cmd.ExecuteNonQuery();

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Appoiment Requested.');", true);
            con.Close();
            txtid.Text = "";
             txtpn.Text="";
             txtspec.Text="";
             txtname.Text="";
             txtdate.Text="";
            txtphno.Text="";
            txtemail.Text="";
            txtmsg.Text = "";
           // Label8.Text = "YOU ARE REGISTERED IN THIS WEBSITE";
            //Label8.Visible = false;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Appointment Confirm.')");
             //   Response.Redirect("pindex.aspx");
                
           // con.Close();
        }

        catch (Exception ex)
        {
            Label9.Text = ex.Message.ToString();
            Label9.Visible = true;

          //  Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please try again.')");
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "scripts", "<script>alert('please try again.');</script>");
            //Response.Redirect("viewdoc.aspx");
         

           // Label9.Text = ex.Message.ToString();
           // Label9.Visible = false;

            //"TRY ONCE AGAIN YOUR ACCOUNT IS NOT REGISTERED";
            //Label2.Visible = true;
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtdate.Text = Calendar1.SelectedDate.ToLongDateString();

        Calendar1.Visible = false;
   
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Calendar1.Visible = true;
    }
}
